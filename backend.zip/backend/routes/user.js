const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "your_jwt_secret_key";

// POST route for user registration
router.post("/register", async (req, res) => {
  const { firstName, lastName, mobile, email, password, role } = req.body;

  try {
    // Validate required fields
    if (!firstName || !lastName || !mobile || !email || !password || !role) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Check if the mobile or email already exists
    let user = await User.findOne({ $or: [{ email }, { mobile }] });
    if (user) {
      return res
        .status(400)
        .json({ message: "User with this email or mobile already exists" });
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create a new user
    user = new User({
      firstName,
      lastName,
      mobile,
      email,
      password: hashedPassword,
      role,
    });

    // Save the user to the database
    await user.save();

    res
      .status(200)
      .json({ status: true, message: "User registered successfully", user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST route for user login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Validate required fields
    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "Email and password are required" });
    }

    // Check if the user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Check if the password is correct
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email,
        role: user.role,
        name: user.firstName + " " + user.lastName,
      },
      "JWT_SECRET",
      { expiresIn: "4h" }
    );

    res.status(200).json({ status: true, message: "Login successful", token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/userdetails", async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: "Email is required" });
  }

  try {
    // Check if the user exists
    const user = await User.findOne({ email }).select("-password"); 
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
