import logo from "./logo.svg";
import "./App.css";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Login from "./pages/Login";
import { useCookies } from "react-cookie";
import PrivateRoute from "./components/PrivateRoute";
import dashboard from "./pages/dashboard";
import HamburgerIcon from "./components/HamburgerIcon";
import Signup from "./pages/signup";

function App() {
  const [cookies] = useCookies(["token"]);
  const isAuthenticated = !!cookies.token; 

  return (
    <div className="App">
      <Router>
        <Routes>
          <Route
            path="/login"
            element={isAuthenticated ? <Navigate to="/" /> : <Login />}
          />
          <Route path="/" element={<PrivateRoute component={dashboard} />} />
          <Route path="/signup" element={<Signup />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
