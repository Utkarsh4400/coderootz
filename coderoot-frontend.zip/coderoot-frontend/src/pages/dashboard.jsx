import React, { useState } from 'react';
import 'tailwindcss/tailwind.css';
import Header from '../components/Header';
import Sidebar from '../components/SideBar';

const Home = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const user = {
    name: "John Doe",
    photo: "https://via.placeholder.com/40", 
  };

  return (
    <div className="relative">
      <Header 
        companyName="My Company" 
        userName={user.name} 
        userPhoto={user.photo} 
        toggleSidebar={toggleSidebar}
      />
      <Sidebar 
        isOpen={isSidebarOpen} 
        toggleSidebar={toggleSidebar} 
        className={`absolute z-30 h-full ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300`}
      />
      <div className="flex bg-zinc-400">
        <div className="flex-1 p-6 transition-all duration-300">
          <h2 className='font-bold text-[20px] flex  px-6 text-white'>Welcome to the DashBoard!!</h2>
          <h3 className='flex text-[16px]  px-6 text-white'>Hope you like the project.</h3>

          <div className="flex flex-wrap w-full mt-4 px-6 py-4 justify-between">
          
            <div className="w-full md:w-1/4 bg-white p-4 shadow-md rounded-md flex flex-col items-center mb-4 md:mb-0">
              <img
                alt=""
                src="https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
                className="h-48 w-full object-cover sm:h-64 lg:h-80"
              />
              <h3 className="mt-4 text-lg font-bold text-gray-900 sm:text-xl">Dummy Data</h3>
              <p className="mt-2 max-w-sm text-gray-700 text-center">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni reiciendis sequi ipsam incidunt.</p>
            </div>

            
            <div className="w-full md:w-1/4 bg-white p-4 shadow-md rounded-md flex flex-col items-center mb-4 md:mb-0">
              <img
                alt=""
                src="https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
                className="h-48 w-full object-cover sm:h-64 lg:h-80"
              />
              <h3 className="mt-4 text-lg font-bold text-gray-900 sm:text-xl">Dummy Data</h3>
              <p className="mt-2 max-w-sm text-gray-700 text-center">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni reiciendis sequi ipsam incidunt.</p>
            </div>

         
            <div className="w-full md:w-1/4 bg-white p-4 shadow-md rounded-md flex flex-col items-center mb-4 md:mb-0">
              <img
                alt=""
                src="https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
                className="h-48 w-full object-cover sm:h-64 lg:h-80"
              />
              <h3 className="mt-4 text-lg font-bold text-gray-900 sm:text-xl">Dummy Data</h3>
              <p className="mt-2 max-w-sm text-gray-700 text-center">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni reiciendis sequi ipsam incidunt.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;