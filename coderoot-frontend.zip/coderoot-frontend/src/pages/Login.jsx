import React, { useState } from 'react';
import { loginApi } from '../lib/user';
import { useCookies } from 'react-cookie';
import { Link } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

const LoginSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string().required('Password is required'),
});

function Login() {
  const [message, setMessage] = useState('');
  const [cookies, setCookie] = useCookies(['token']);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async (values, { setSubmitting }) => {
    try {
      const { email, password } = values;
      const payload = { email, password };

      const loginRes = await loginApi(payload);
      console.log(loginRes);

      if (loginRes.status) {
        const token = loginRes.token;
        setCookie('token', token, { path: '/', maxAge: 3600 * 24 * 7 });
        setMessage('Login successful');
      } else {
        setMessage(loginRes.message || 'Login failed');
      }
    } catch (error) {
      setMessage('An error occurred during login.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-gray-100 overflow-hidden">
      <video
        className="absolute inset-0 w-full h-full object-cover z-0"
        src="https://res.cloudinary.com/drujmiwhq/video/upload/v1721899565/bgVID_dzi6qw.mp4" 
        type="video/mp4"
        autoPlay
        loop
        muted
      />
      <div className="relative z-10 max-w-md w-full mx-4 bg-black shadow-md rounded-lg px-8 pt-6 pb-8 mb-4 opacity-90">
        <h2 className="text-2xl mb-6 text-center text-white">Login</h2>
        <Formik
          initialValues={{ email: '', password: '' }}
          validationSchema={LoginSchema}
          onSubmit={handleLogin}
        >
          {({ isSubmitting }) => (
            <Form>
              <div className="mb-4">
                <Field
                  type="email"
                  name="email"
                  placeholder="Email"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                <ErrorMessage name="email" component="div" className="text-red-500 text-xs italic" />
              </div>
              <div className="mb-6 relative">
                <Field
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  placeholder="Password"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                />
                <span
                  className="absolute inset-y-0 right-10 pr-3 flex items-center text-sm leading-5 cursor-pointer"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </span>
                <ErrorMessage name="password" component="div" className="text-red-500 text-xs italic" />
              </div>
              <div className="flex items-center justify-center">
                <button
                  type="submit"
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline"
                  disabled={isSubmitting}
                >
                  Login
                </button>
              </div>
            </Form>
          )}
        </Formik>
        {message && <p className="mt-4 text-center text-red-500">{message}</p>}
        <p className="mt-4 text-center text-white">
          Don't have an account? <Link to="/signup" className="text-blue-500 underline">SignUp?</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;