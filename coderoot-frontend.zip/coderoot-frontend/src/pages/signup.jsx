import React, { useContext, useState } from "react";
import { AuthUserContext } from "../lib/authContext";
import { Link, useNavigate } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { registerUser } from "../lib/user";


const SignupSchema = Yup.object().shape({
  firstName: Yup.string()
    .matches(/^[A-Za-z]+$/, 'First Name must contain only letters')
    .required('First Name is required'),
  lastName: Yup.string()
    .matches(/^[A-Za-z]+$/, 'Last Name must contain only letters')
    .required('Last Name is required'),
  mobile: Yup.string()
    .matches(/^[0-9]+$/, 'Mobile must contain only numbers')
    .required('Mobile is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string()
    .min(6, 'Password must be at least 6 characters')
    .max(20, 'Password cannot exceed 20 characters')
    .matches(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .matches(/[a-z]/, 'Password must contain at least one lowercase letter')
    .matches(/[0-9]/, 'Password must contain at least one number')
    .matches(/[!@#$%^&*(),.?":{}|<>]/, 'Password must contain at least one special character')
    .required('Password is required'),
  role: Yup.string(),
});

const Signup = () => {
  const { userLoginDetails } = useContext(AuthUserContext);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate()

  const handleSignupSubmit = async (values, { setSubmitting }) => {
    try {
      const payload = {
        firstName: values.firstName,
        lastName: values.lastName,
        mobile: values.mobile,
        email: values.email,
        password: values.password,
        role:
          userLoginDetails?.role === "SuperAdmin"
            ? values.role
            : userLoginDetails?.role === "User"
              ? "User"
              : userLoginDetails?.role === "SubUser"
                ? "SubUser"
                : "SubUser",
      };
      const signUpRes = await registerUser(payload)

      if (signUpRes?.status) {
        navigate("/login")
      }

      console.log(signUpRes?.status, "aaaa")
     
    }
    catch (err) {
      console.log(err)
    }

  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-gray-100 overflow-hidden">
      <video
        className="absolute inset-0 w-full h-full object-cover z-0"
        src="https://res.cloudinary.com/drujmiwhq/video/upload/v1721899565/bgVID_dzi6qw.mp4"  
        type="video/mp4"
        autoPlay
        loop
        muted
      />
      <div className="relative z-10 max-w-md w-full mx-4 bg-black shadow-md rounded-lg px-8 pt-6 pb-8 mb-4 opacity-90">
        <h2 className="text-2xl mb-6 text-center text-white">Sign Up</h2>
        <Formik
          initialValues={{ firstName: '', lastName: '', mobile: '', email: '', password: '', role: '' }}
          validationSchema={SignupSchema}
          onSubmit={handleSignupSubmit}
        >
          {({ errors, handleChange, handleSubmit, values, isSubmitting }) => (
            <Form>
              <div className="mb-4">
                <Field
                  type="text"
                  name="firstName"
                  placeholder="First Name"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                <ErrorMessage name="firstName" component="div" className="text-red-500 text-xs italic" />
              </div>
              <div className="mb-4">
                <Field
                  type="text"
                  name="lastName"
                  placeholder="Last Name"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                <ErrorMessage name="lastName" component="div" className="text-red-500 text-xs italic" />
              </div>
              <div className="mb-4">
                <Field
                  type="text"
                  name="mobile"
                  placeholder="Mobile"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                <ErrorMessage name="mobile" component="div" className="text-red-500 text-xs italic" />
              </div>
              <div className="mb-4">
                <Field
                  type="email"
                  name="email"
                  placeholder="Email"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                <ErrorMessage name="email" component="div" className="text-red-500 text-xs italic" />
              </div>
              <div className="mb-6 relative">
                <Field
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  placeholder="Password"
                  className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                <span
                  className="absolute inset-y-0 right-10 pr-3 flex items-center text-sm leading-5 cursor-pointer"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </span>
                <ErrorMessage name="password" component="div" className="text-red-500 text-xs italic" />
              </div>
              {userLoginDetails?.role === "SuperAdmin" && (
                <div className="mb-4">
                  <Field
                    type="text"
                    name="role"
                    placeholder="Role"
                    className="shadow appearance-none border rounded-lg w-3/4 mx-auto py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                  <ErrorMessage name="role" component="div" className="text-red-500 text-xs italic" />
                </div>
              )}
              <div className="flex items-center justify-center">
                <button
                  type="submit"
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline"
                  disabled={isSubmitting}
                >
                  Sign Up
                </button>
              </div>
            </Form>
          )}
        </Formik>
        <p className="mt-4 text-center text-white">
          Already have an account?{" "}
          <Link to="/" className="text-blue-500 underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Signup;