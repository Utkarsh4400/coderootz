// src/routes.jsx
import React from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import PrivateRoute from './PrivateRoute';
import Login from '../pages/Login';


const Routes = () => {
    const isAuthenticated = !!localStorage.getItem('token');

    return (
        <Router>
            <Switch>
                <Route
                    exact
                    path="/login"
                  render={() =>
                   isAuthenticated ? <Redirect to="/" /> : <Login />
                  }
                />
                <PrivateRoute exact path="/" component={Home} /> 
                Add more private routes below as needed
                <PrivateRoute path="/another-private-route" component={AnotherComponent} />
            </Switch>
        </Router>
    );
};

export default Routes;