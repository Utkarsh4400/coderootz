import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useCookies } from 'react-cookie';

const PrivateRoute = ({ component: Component }) => {
  const [cookies] = useCookies(['token']); 
  const isAuthenticated = !!cookies.token; 

  return isAuthenticated ? <Component /> : <Navigate to="/login" />;
};

export default PrivateRoute;