import React, { useContext } from 'react';
import { AuthUserContext } from '../lib/authContext';
import { FaArrowLeft } from 'react-icons/fa';

const Sidebar = ({ isOpen, toggleSidebar }) => {
  const { userLoginDetails } = useContext(AuthUserContext);

  console.log(userLoginDetails);

  return (
    <div
      className={`fixed inset-y-0 left-0 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } transition-transform duration-500 ease-in-out bg-black text-white ${
        isOpen ? 'w-64' : 'w-0'
      } overflow-hidden`}>
      <div className="p-4">
        <div className='flex justify-between items-center'>
          <span className='cursor-pointer mt-4 ' onClick={toggleSidebar}> <FaArrowLeft /></span>
        </div>
        <nav>
          <ul className="text-left">
            <li className="p-3 mt-12 hover:bg-gray-700 rounded-md cursor-pointer">Home</li>
            <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">About Us</li>
            <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Contact Us</li>
            {(userLoginDetails?.role === "user" || userLoginDetails?.role === "SuperAdmin") && 
              <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Media</li>
            }
            {(userLoginDetails?.role === "user" || userLoginDetails?.role === "SuperAdmin") && 
              <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Plugins</li>
            }
            <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Users</li>
            <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Tools</li>
            {userLoginDetails?.role === "SuperAdmin" &&  
              <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Comments</li>
            }
            {userLoginDetails?.role === "SuperAdmin" &&  
              <li className="p-3 hover:bg-gray-700 rounded-md cursor-pointer">Settings</li>
            }
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;