import React, { useState, useContext } from "react";
import HamburgerIcon from "./HamburgerIcon";
import { AuthUserContext } from "../lib/authContext";
import { useNavigate } from "react-router-dom";

const Header = ({ toggleSidebar }) => {
  const { userLoginDetails, logout } = useContext(AuthUserContext);
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setDropdownVisible(!dropdownVisible);
  };

  const handleUserLogout = async () => {
    try {
     
      const cookiesToClear = ["token"];
      cookiesToClear.forEach((cookieName) => {
        document.cookie = `${cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
      });

      navigate("/login");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <header className="flex justify-between items-center p-4 bg-black shadow-md text-white">
      <HamburgerIcon toggleSidebar={toggleSidebar} />
      <div className="text-xl font-bold">CODEROOTZ</div>
      <div className="relative">
        <div className="flex flex-col items-center" onClick={toggleDropdown}>
          <img
            src={require("./../../src/userIMG.jpg")}
            alt={`${userLoginDetails.name}'s profile`}
            className="w-8 h-8 rounded-full mb-2 cursor-pointer"
          />
          <span className="text-xs font-medium">{userLoginDetails.name}</span>
        </div>
        {dropdownVisible && (
          <div className="absolute top-full right-0 mt-2 w-24 bg-black text-white text-center rounded shadow-lg">
            <button
              className="w-full px-4 py-2 text-red-500 hover:bg-gray-800"
              onClick={handleUserLogout}
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;